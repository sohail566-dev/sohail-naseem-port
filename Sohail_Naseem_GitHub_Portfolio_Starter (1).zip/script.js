async function loadPortfolio(){
 const res=await fetch('portfolio-data.json'); const d=await res.json();
 const set=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=value||''};
 set('name',d.name);set('headline',d.headline);set('intro',d.intro);set('location',d.location);
 set('aboutText',d.about);set('philosophy',d.teachingPhilosophy);set('careerGoal',d.careerGoal);set('footerName',d.name);
 const tags=(id,items)=>{document.getElementById(id).innerHTML=(items||[]).map(x=>`<span class="tag">${escapeHtml(x)}</span>`).join('')};
 tags('teachingAreas',d.teachingAreas);tags('skills',d.skills);tags('certifications',d.certifications);tags('languages',d.languages);
 document.getElementById('experienceList').innerHTML=(d.experience||[]).map(x=>`<article class="card"><h3>${escapeHtml(x.role)}</h3><p class="meta">${escapeHtml(x.organization)} · ${escapeHtml(x.duration||'')}</p><ul>${(x.highlights||[]).map(y=>`<li>${escapeHtml(y)}</li>`).join('')}</ul></article>`).join('');
 document.getElementById('educationList').innerHTML=(d.education||[]).map(x=>`<div class="timeline-item"><h3>${escapeHtml(x.qualification)}</h3><p>${escapeHtml(x.institution)} · ${escapeHtml(x.period||'')} ${escapeHtml(x.detail||'')}</p></div>`).join('');
 const links=[['Email',`mailto:${d.email}`],['Phone',`tel:${(d.phone||'').replace(/\\s/g,'')}`]];
 if(d.links?.linkedin)links.push(['LinkedIn',d.links.linkedin]);if(d.links?.github)links.push(['GitHub',d.links.github]);
 document.getElementById('contactLinks').innerHTML=links.map(([t,u])=>`<a href="${escapeAttr(u)}">${escapeHtml(t)}: ${escapeHtml(t==='Email'?d.email:t==='Phone'?d.phone:u)}</a>`).join('');
}
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function escapeAttr(s=''){return escapeHtml(s)}
loadPortfolio().catch(()=>{document.getElementById('intro').textContent='Please open this site using a local web server or GitHub Pages.'});
