# Sohail Naseem — Teaching Portfolio

A responsive, static personal portfolio website for GitHub Pages.

## Files
- `index.html` — website structure
- `style.css` — responsive visual design
- `script.js` — loads profile content
- `portfolio-data.json` — editable profile information
- `assets/` — add your profile photo and supporting images here

## Preview locally
Because the site loads `portfolio-data.json`, run it through a local server rather than opening `index.html` directly.

If Python is installed:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

## Publish with GitHub Pages
1. Create a new public repository, for example `sohail-naseem-portfolio`.
2. Upload all files and folders from this package to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish your site.

## Personalize later
- Edit `portfolio-data.json` to update your biography, education, certificates, links and experience.
- Add your photo in `assets/`, then update the photo section in `index.html` when your image is provided.
- Add the PDF file to the repository root using the filename `Sohail_Naseem_Teaching_Portfolio.pdf` so the PDF button works.
- Add your LinkedIn and GitHub profile URLs in `portfolio-data.json`.

## Important
This starter is based on the CV details currently available. Please verify dates, qualifications, job titles and contact details before publishing. The profile photo is intentionally a placeholder until you provide the image.
